import UploadVideo from "./UploadVideo";

export default function Upload() {
  return <UploadVideo />;
}
